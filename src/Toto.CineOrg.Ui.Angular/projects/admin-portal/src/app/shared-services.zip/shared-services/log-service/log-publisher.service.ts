import {Injectable} from '@angular/core';
import {LogPublisher} from './log-publisher';
import {ConsoleLogPublisher} from './publishers/console-log-publisher';
import {PersistenceService} from '../persistence-service/persistence.service';
import {IndexedDbLogPublisher} from './publishers/indexed-db-log-publisher';

@Injectable({
  providedIn: 'root'
})
export class LogPublisherService {

  public publishers: LogPublisher[] = [];

  constructor(private persistenceService: PersistenceService) {
    this.buildPublishers();
  }

  private buildPublishers(): void {
    // TODO: More publishers and read from config...

    const consolePublisher = new ConsoleLogPublisher();
    this.publishers.push(consolePublisher);

    const indexedDBPublisher = new IndexedDbLogPublisher(this.persistenceService);
    this.publishers.push(indexedDBPublisher);
  }
}
