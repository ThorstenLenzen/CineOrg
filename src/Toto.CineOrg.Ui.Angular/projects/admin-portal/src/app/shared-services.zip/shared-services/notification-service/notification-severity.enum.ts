export enum NotificationSeverity {
  success,
  info,
  error,
  warning
}
