import {LogPublisher} from '../log-publisher';
import {Observable, of} from 'rxjs';
import {LogEntry} from '../log-entry';
import {PersistenceService, LOG_STORE_NAME} from '../../persistence-service/persistence.service';

export class IndexedDbLogPublisher extends LogPublisher {

  constructor(private persistenceService: PersistenceService) {
    super();
  }

  clear(): Observable<boolean> {
    // TODO
    return undefined;
  }

  write(entry: LogEntry): Observable<boolean> {
    this.persistenceService.save(LOG_STORE_NAME, entry.buildLogString());

    return of(true);
  }
}
