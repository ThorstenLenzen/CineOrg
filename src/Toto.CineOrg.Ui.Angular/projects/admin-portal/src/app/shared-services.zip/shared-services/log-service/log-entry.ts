import {LogLevel} from './log-level';

export class LogEntry {
  message: string;
  logLevel: LogLevel;
  extraInfo: any[];
  logWithDate: boolean;

  public buildLogString(): string {
    let entry: string;

    if (this.logWithDate) {
      entry = `(${this.dateTimeNow()}) `;
    }

    entry += `[${LogLevel[this.logLevel]}]: ${this.message}; ${this.formatParams(this.extraInfo)}`;

    return entry;
  }

  private formatParams(params: any[]): string {
    if (params == null || params === undefined) {
      return '';
    }

    let ret: string = params.join(', ');

    // Is there at least one object in the array?
    if (params.some(p => typeof p === 'object')) {
      ret = '';

      // Build comma-delimited string
      for (const item of params) {
        ret += JSON.stringify(item) + ', ';
      }
    }

    return ret;
  }

  private dateTimeNow(): string {
    const now = new Date();
    const date = now.getFullYear() + '-' + (now.getMonth() + 1) + '-' + now.getDate();
    const time = now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
    return date + ' ' + time;
  }
}
